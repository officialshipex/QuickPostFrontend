import React from "react";
import EmailLayout from "../components/EmailLayout";
import { Heading, Greeting, Text, InfoTable, Button, StatusTracker } from "../components/blocks";

export const subject = "Delivered: {{ShipmentID}}";

export default function OrderDelivered({
  firstName = "{{FirstName}}",
  shipmentId = "{{ShipmentID}}",
  deliveredDate = "{{DeliveredDate}}",
  receiverName = "{{ReceiverName}}",
  feedbackLink = "{{FeedbackLink}}",
}) {
  return (
    <EmailLayout hero={{ file: "hero-delivered.png", alt: "Delivered parcel with a checkmark" }} preview={`Shipment ${shipmentId} was delivered on ${deliveredDate}.`}>
      <Heading>Delivered successfully</Heading>
      <StatusTracker current={3} />
      <Greeting name={firstName} />
      <Text>Your shipment has been delivered.</Text>
      <InfoTable
        rows={[
          { label: "Shipment ID", value: shipmentId },
          { label: "Delivered on", value: deliveredDate },
          { label: "Received by", value: receiverName },
        ]}
      />
      <Text>Thank you for choosing Quickpost. Tell us how we did, it takes 10 seconds.</Text>
      <Button href={feedbackLink}>Rate your delivery</Button>
    </EmailLayout>
  );
}
