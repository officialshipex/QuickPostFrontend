import React from "react";
import EmailLayout from "../components/EmailLayout";
import { Heading, Greeting, Text, InfoTable, Button, StatusTracker, Notice } from "../components/blocks";

export const subject = "Out for delivery: {{ShipmentID}} arrives today";

export default function OutForDelivery({
  firstName = "{{FirstName}}",
  shipmentId = "{{ShipmentID}}",
  trackingId = "{{TrackingID}}",
  expectedDate = "{{ExpectedDate}}",
  trackingLink = "{{TrackingLink}}",
}) {
  return (
    <EmailLayout hero={{ file: "hero-out-for-delivery.png", alt: "Quickpost rider on a scooter" }} preview={`Shipment ${shipmentId} is out for delivery and will reach you soon.`}>
      <Heading>Out for delivery</Heading>
      <StatusTracker current={2} />
      <Greeting name={firstName} />
      <Text>Your shipment is out for delivery and will reach you soon.</Text>
      <InfoTable
        rows={[
          { label: "Shipment ID", value: shipmentId },
          { label: "Tracking ID", value: trackingId },
          { label: "Expected delivery", value: expectedDate, tone: "success" },
        ]}
      />
      <Notice icon="icon-phone-ring.png">
        Keep your phone nearby. Our delivery partner may call you when they arrive.
      </Notice>
      <Button href={trackingLink}>Track live</Button>
    </EmailLayout>
  );
}
