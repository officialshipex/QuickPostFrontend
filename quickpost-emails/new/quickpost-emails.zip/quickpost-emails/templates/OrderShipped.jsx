import React from "react";
import EmailLayout from "../components/EmailLayout";
import { Heading, Greeting, Text, InfoTable, Button, StatusTracker } from "../components/blocks";

export const subject = "Your shipment {{ShipmentID}} is on its way";

export default function OrderShipped({
  firstName = "{{FirstName}}",
  shipmentId = "{{ShipmentID}}",
  trackingId = "{{TrackingID}}",
  pickupDate = "{{PickupDate}}",
  trackingLink = "{{TrackingLink}}",
}) {
  return (
    <EmailLayout hero={{ file: "hero-shipped.png", alt: "Quickpost delivery truck in motion" }} preview={`Shipment ${shipmentId} has been picked up and is on its way.`}>
      <Heading>Your order is on its way</Heading>
      <StatusTracker current={1} />
      <Greeting name={firstName} />
      <Text>Your shipment has been picked up and is moving through our network.</Text>
      <InfoTable
        rows={[
          { label: "Shipment ID", value: shipmentId },
          { label: "Tracking ID", value: trackingId },
          { label: "Picked up on", value: pickupDate },
        ]}
      />
      <Button href={trackingLink}>Track shipment</Button>
    </EmailLayout>
  );
}
