import React from "react";
import EmailLayout from "../components/EmailLayout";
import { Heading, Greeting, Text, InfoTable, Button } from "../components/blocks";

export const subject = "COD remittance of {{Amount}} processed";

export default function CodRemittance({
  firstName = "{{FirstName}}",
  remittanceId = "{{RemittanceID}}",
  settlementDate = "{{SettlementDate}}",
  amount = "{{Amount}}",
  bankRefNo = "{{BankRefNo}}",
  remittanceLink = "{{RemittanceLink}}",
}) {
  return (
    <EmailLayout hero={{ file: "hero-cod.png", alt: "Wallet with cash and a checkmark" }} preview={`${amount} has been remitted to your bank account.`}>
      <Heading>COD remittance processed</Heading>
      <Greeting name={firstName} />
      <Text>We've processed your cash-on-delivery remittance. Here are the details.</Text>
      <InfoTable
        rows={[
          { label: "Amount remitted", value: amount, tone: "success" },
          { label: "Remittance ID", value: remittanceId },
          { label: "Settlement date", value: settlementDate },
          { label: "Bank reference no.", value: bankRefNo },
        ]}
      />
      <Text>The amount will be credited to your bank account shortly.</Text>
      <Button href={remittanceLink}>View remittance</Button>
    </EmailLayout>
  );
}
