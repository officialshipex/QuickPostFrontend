import React from "react";
import { colors, font, img } from "../theme";

const P = (props) => (
  <table role="presentation" width="100%" cellPadding="0" cellSpacing="0" border="0" {...props} />
);

/* ── Hero illustration (600×400 file, shown at 300×200) ── */
export function Hero({ file, alt = "" }) {
  return (
    <P>
      <tbody>
        <tr>
          <td align="center" style={{ padding: "16px 0 8px" }}>
            <img
              src={img(file)}
              width="300"
              height="200"
              alt={alt}
              style={{ display: "block", width: 300, maxWidth: "100%", height: "auto" }}
            />
          </td>
        </tr>
      </tbody>
    </P>
  );
}

/* ── Headline ── */
export function Heading({ children, sub }) {
  return (
    <div style={{ textAlign: "center", margin: "0 0 28px" }}>
      <h1
        className="qp-h1"
        style={{
          margin: 0,
          fontFamily: font,
          fontSize: 26,
          lineHeight: "34px",
          fontWeight: 700,
          color: colors.ink,
          letterSpacing: "-0.3px",
        }}
      >
        {children}
      </h1>
      {sub ? (
        <div style={{ marginTop: 8, fontFamily: font, fontSize: 14, color: colors.muted }}>{sub}</div>
      ) : null}
    </div>
  );
}

/* ── Paragraph ── */
export function Text({ children, muted, center, style }) {
  return (
    <p
      style={{
        margin: "0 0 16px",
        fontFamily: font,
        fontSize: 15,
        lineHeight: "24px",
        color: muted ? colors.muted : colors.body,
        textAlign: center ? "center" : "left",
        ...style,
      }}
    >
      {children}
    </p>
  );
}

export function Greeting({ name = "{{FirstName}}" }) {
  return (
    <Text style={{ color: colors.ink, fontWeight: 600 }}>Hi {name},</Text>
  );
}

/* ── Bulletproof button (works in Outlook) ── */
export function Button({ href = "#", children }) {
  return (
    <table
      role="presentation"
      cellPadding="0"
      cellSpacing="0"
      border="0"
      align="center"
      style={{ margin: "28px auto 8px" }}
    >
      <tbody>
        <tr>
          <td align="center" style={{ backgroundColor: colors.primary, borderRadius: 10 }}>
            <a
              href={href}
              target="_blank"
              rel="noreferrer"
              style={{
                display: "inline-block",
                padding: "14px 36px",
                fontFamily: font,
                fontSize: 15,
                fontWeight: 600,
                lineHeight: "20px",
                color: "#FFFFFF",
                textDecoration: "none",
                borderRadius: 10,
              }}
            >
              {children}
            </a>
          </td>
        </tr>
      </tbody>
    </table>
  );
}

/* ── Label / value table ──
   rows: [{ label, value, icon?, tone?: "danger" | "warning" | "success" }] */
export function InfoTable({ rows }) {
  const toneColor = { danger: colors.danger, warning: colors.warning, success: colors.primary };
  return (
    <P
      style={{
        backgroundColor: colors.surface,
        border: `1px solid ${colors.border}`,
        borderRadius: 12,
        borderCollapse: "separate",
        margin: "8px 0 24px",
      }}
    >
      <tbody>
        {rows.map((r, i) => (
          <tr key={r.label}>
            <td
              style={{
                padding: "14px 0 14px 20px",
                borderTop: i === 0 ? "none" : `1px solid ${colors.border}`,
                fontFamily: font,
                fontSize: 13,
                lineHeight: "20px",
                color: colors.muted,
                width: "42%",
                verticalAlign: "middle",
              }}
            >
              {r.icon ? (
                <img
                  src={img(r.icon)}
                  width="18"
                  height="18"
                  alt=""
                  style={{ display: "inline-block", verticalAlign: "middle", marginRight: 8 }}
                />
              ) : null}
              <span style={{ verticalAlign: "middle" }}>{r.label}</span>
            </td>
            <td
              style={{
                padding: "14px 20px 14px 12px",
                borderTop: i === 0 ? "none" : `1px solid ${colors.border}`,
                fontFamily: font,
                fontSize: 14,
                lineHeight: "20px",
                fontWeight: 600,
                color: r.tone ? toneColor[r.tone] : colors.ink,
                textAlign: "right",
                verticalAlign: "middle",
                wordBreak: "break-word",
              }}
            >
              {r.value}
            </td>
          </tr>
        ))}
      </tbody>
    </P>
  );
}

/* ── Callout box with icon ── */
export function Notice({ icon, tone = "success", children }) {
  const bg = { success: colors.primaryTint, warning: colors.warningTint, danger: colors.dangerTint }[tone];
  return (
    <P style={{ backgroundColor: bg, borderRadius: 12, borderCollapse: "separate", margin: "8px 0 24px" }}>
      <tbody>
        <tr>
          {icon ? (
            <td style={{ width: 24, padding: "14px 0 14px 18px", verticalAlign: "top" }}>
              <img src={img(icon)} width="24" height="24" alt="" style={{ display: "block" }} />
            </td>
          ) : null}
          <td
            style={{
              padding: "14px 18px 14px 12px",
              fontFamily: font,
              fontSize: 13,
              lineHeight: "20px",
              color: colors.body,
              verticalAlign: "middle",
            }}
          >
            {children}
          </td>
        </tr>
      </tbody>
    </P>
  );
}

/* ── OTP code box (works with a real code or a {{OTP}} placeholder) ── */
export function OtpCode({ code = "{{OTP}}" }) {
  return (
    <P style={{ margin: "8px 0 16px" }}>
      <tbody>
        <tr>
          <td align="center">
            <div
              className="qp-otp"
              style={{
                display: "inline-block",
                padding: "16px 20px 16px 32px",
                border: `2px dashed ${colors.primary}`,
                borderRadius: 12,
                backgroundColor: colors.primaryTint,
                fontFamily: "'Courier New', Courier, monospace",
                fontSize: 34,
                lineHeight: "40px",
                fontWeight: 700,
                letterSpacing: 12,
                color: colors.primaryDark,
              }}
            >
              {code}
            </div>
          </td>
        </tr>
      </tbody>
    </P>
  );
}

/* ── Shipment progress tracker ──
   current: 0 Booked · 1 Shipped · 2 Out for delivery · 3 Delivered
   failed:  true marks the current step red (used by NDR) */
const STEPS = ["Booked", "Shipped", "Out for delivery", "Delivered"];

export function StatusTracker({ current = 0, failed = false }) {
  return (
    <P style={{ margin: "4px 0 28px" }}>
      <tbody>
        <tr>
          {STEPS.map((label, i) => {
            const done = i < current;
            const active = i === current;
            const isFail = failed && active;
            const barColor = isFail ? colors.danger : i <= current ? colors.primary : colors.border;
            const textColor = isFail ? colors.danger : i <= current ? colors.primaryDark : colors.muted;
            return (
              <td key={label} width="25%" style={{ padding: "0 3px", verticalAlign: "top" }}>
                <P>
                  <tbody>
                    <tr>
                      <td
                        style={{
                          height: 6,
                          fontSize: 0,
                          lineHeight: "6px",
                          backgroundColor: barColor,
                          borderRadius: 3,
                        }}
                      >
                        {"\u00A0"}
                      </td>
                    </tr>
                  </tbody>
                </P>
                <div
                  style={{
                    marginTop: 8,
                    fontFamily: font,
                    fontSize: 12,
                    lineHeight: "16px",
                    textAlign: "center",
                    fontWeight: active ? 700 : 500,
                    color: textColor,
                  }}
                >
                  {done ? "✓ " : ""}
                  {isFail ? "Attempt failed" : label}
                </div>
              </td>
            );
          })}
        </tr>
      </tbody>
    </P>
  );
}

/* ── 3-column stat grid for reports ──
   stats: [{ icon, label, value, tone? }] */
export function StatGrid({ stats }) {
  const rows = [];
  for (let i = 0; i < stats.length; i += 3) rows.push(stats.slice(i, i + 3));
  const toneColor = { danger: colors.danger, success: colors.primary };
  return (
    <P style={{ margin: "8px 0 16px", tableLayout: "fixed" }}>
      <tbody>
        {rows.map((row, r) => (
          <tr key={r}>
            {row.map((s) => (
              <td key={s.label} width="33%" style={{ padding: 5, verticalAlign: "top" }}>
                <P
                  style={{
                    backgroundColor: colors.surface,
                    border: `1px solid ${colors.border}`,
                    borderRadius: 12,
                    borderCollapse: "separate",
                  }}
                >
                  <tbody>
                    <tr>
                      <td align="center" style={{ padding: "18px 8px 16px", fontFamily: font }}>
                        <img src={img(s.icon)} width="40" height="40" alt="" style={{ display: "block", margin: "0 auto" }} />
                        <div
                          className="qp-stat-value"
                          style={{
                            marginTop: 10,
                            fontSize: 24,
                            lineHeight: "30px",
                            fontWeight: 700,
                            color: s.tone ? toneColor[s.tone] : colors.ink,
                            wordBreak: "break-word",
                          }}
                        >
                          {s.value}
                        </div>
                        <div style={{ marginTop: 2, fontSize: 12, lineHeight: "16px", color: colors.muted }}>
                          {s.label}
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </P>
              </td>
            ))}
          </tr>
        ))}
      </tbody>
    </P>
  );
}
